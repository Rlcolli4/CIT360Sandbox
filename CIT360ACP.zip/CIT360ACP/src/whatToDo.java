
public interface whatToDo { //This is an interface containing a method that we will use to calculate different sums in our code.
	void execute(Integer numberA, Integer numberB); //This method takes in the two numbers for use later.
}
