import java.util.Scanner;

public class modulizeIt implements whatToDo{ //this implements the interface we made earlier and it's method to execute a needed function.
	public void execute(Integer numberA, Integer numberB) {
		Integer theNumber = numberA % numberB;
		System.out.println("The Answer is [" + theNumber + "].");
		
		//the next section of code will rerun the calculator and allow us to do more operations.
		String commandPrompt;
		controllerSays delegateIt = new controllerSays(); 
		
		Scanner userInput = new Scanner(System.in);
		//This takes in the data needed to run our calculator.
		System.out.print("Please enter a number: ");
		numberA = Integer.parseInt(userInput.nextLine());
		
		System.out.println("Please enter one of the following ");
		System.out.print("+, -, /, *, ^, or %: ");
		commandPrompt = userInput.nextLine();
		
		System.out.print("Please enter a number: ");
		numberB = Integer.parseInt(userInput.nextLine());
		//This will print out the initial user input
		System.out.println(numberA + commandPrompt + numberB);
		
		//This will delegate the information over to the Controller where our interfaces and methods will do the work.
		delegateIt.handleUserInput(commandPrompt, numberA, numberB);
	}
}
