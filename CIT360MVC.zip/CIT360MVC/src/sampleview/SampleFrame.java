package sampleview;

import javax.swing.JFrame;

import samplecontroller.SampleController; //This code is explained at line 10.

public class SampleFrame extends JFrame {
	private SamplePanel basePanel;//This creates a reference to our panel that we have over in teh sample panel area.
	
	/*
	 * The following code takes the SampleController to pass it to the panel later.
	 * The import statement above allows us to user it.
	 */
	public SampleFrame(SampleController baseController) {
		basePanel = new SamplePanel(baseController);
		setUpFrame();
	}
	
	private void setUpFrame() {
		this.setContentPane(basePanel); //This sets the content pane for the users on start up.
		this.setSize(500, 500); //This sets the screen size at 500x500 pixels
		this.setVisible(true); //This goes last to make sure the above parameters are set up before running.
	}
}
