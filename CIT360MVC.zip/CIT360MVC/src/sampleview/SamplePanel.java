package sampleview;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import samplecontroller.SampleController; //needed so we can use the sample controller
import samplemodel.ClassT;
import samplemodel.Grade;

public class SamplePanel extends JPanel {

	//This creates the reference to the base controller mentioned in SampleFrame
	private SampleController baseController;
	
	//This information starts the building of the interface so that we can implement it in the panel for use in the application.
	//These are labels for the fields.
	private JLabel gpaNumberLabel;
	private JLabel letterLabel;
	private JLabel keyValueLabel;
	private JLabel courseCodeLabel;
	//THis is the data fields.
	private JTextField gpaNumberField;
	private JTextField letterField;
	private JTextField keyValueField;
	private JTextField courseCodeField;
	//These are my buttons.
	private JButton createClass;
	private JButton createGrade;
	//the layout.
	private SpringLayout standardLayout;
	
	
	//Now we make the constructor for the SamplePanel with our baseController
	public SamplePanel(SampleController baseController) {
		this.baseController = baseController;
		
		//This establishes our UI elements.
		gpaNumberLabel = new JLabel("Enter the GPA with a period - Example 4.0: ");
		letterLabel = new JLabel("Enter the associated letter grade - Example A: ");
		keyValueLabel = new JLabel("Enter a Number Value - Example 1: ");
		courseCodeLabel = new JLabel("Enter the course code - Example CIT 360: ");
		
		gpaNumberField = new JTextField(20);
		letterField = new JTextField(20);
		keyValueField = new JTextField(20);
		courseCodeField = new JTextField(20);
		
		createClass = new JButton("Enter Class");
		createGrade = new JButton("Enter Possible Grade");
		
		standardLayout = new SpringLayout();
		
		
		//this calls our helper methods below.
		setUpLayout();
		setUpPanel();
		setUpListeners();
	}
	
	/*
	 * These helper methods will help us set up the layout for our pane for use by the user.
	 * The first handles the general layout
	 * the second handles the panel
	 * and the third takes care of our listeners for our application.
	 */
	
	private void setUpLayout() { //I used windowBuilder to align these values here.
		standardLayout.putConstraint(SpringLayout.NORTH, createClass, -5, SpringLayout.NORTH, courseCodeLabel);
		standardLayout.putConstraint(SpringLayout.EAST, createClass, -43, SpringLayout.EAST, this);
		standardLayout.putConstraint(SpringLayout.NORTH, courseCodeField, 6, SpringLayout.SOUTH, courseCodeLabel);
		standardLayout.putConstraint(SpringLayout.EAST, courseCodeField, 0, SpringLayout.EAST, gpaNumberLabel);
		standardLayout.putConstraint(SpringLayout.NORTH, courseCodeLabel, 6, SpringLayout.SOUTH, keyValueField);
		standardLayout.putConstraint(SpringLayout.WEST, courseCodeLabel, 0, SpringLayout.WEST, gpaNumberLabel);
		standardLayout.putConstraint(SpringLayout.NORTH, keyValueField, 6, SpringLayout.SOUTH, keyValueLabel);
		standardLayout.putConstraint(SpringLayout.WEST, keyValueField, 10, SpringLayout.WEST, keyValueLabel);
		standardLayout.putConstraint(SpringLayout.NORTH, keyValueLabel, 16, SpringLayout.SOUTH, letterField);
		standardLayout.putConstraint(SpringLayout.WEST, keyValueLabel, 0, SpringLayout.WEST, gpaNumberLabel);
		standardLayout.putConstraint(SpringLayout.NORTH, createGrade, 48, SpringLayout.NORTH, this);
		standardLayout.putConstraint(SpringLayout.WEST, createGrade, 12, SpringLayout.EAST, letterLabel);
		standardLayout.putConstraint(SpringLayout.WEST, gpaNumberLabel, 0, SpringLayout.WEST, this);
		standardLayout.putConstraint(SpringLayout.NORTH, letterField, 6, SpringLayout.SOUTH, letterLabel);
		standardLayout.putConstraint(SpringLayout.WEST, letterField, 10, SpringLayout.WEST, letterLabel);
		standardLayout.putConstraint(SpringLayout.NORTH, letterLabel, 6, SpringLayout.SOUTH, gpaNumberField);
		standardLayout.putConstraint(SpringLayout.WEST, letterLabel, 0, SpringLayout.WEST, gpaNumberLabel);
		standardLayout.putConstraint(SpringLayout.NORTH, gpaNumberField, 6, SpringLayout.SOUTH, gpaNumberLabel);
		standardLayout.putConstraint(SpringLayout.EAST, gpaNumberField, -10, SpringLayout.EAST, gpaNumberLabel);
		standardLayout.putConstraint(SpringLayout.NORTH, gpaNumberLabel, 10, SpringLayout.NORTH, this);
	}
	
	private void setUpPanel() {
		
		this.setSize(500,500);
		this.setLayout(standardLayout);
		this.add(gpaNumberLabel);
		this.add(letterLabel);
		this.add(keyValueLabel);
		this.add(courseCodeLabel);
		this.add(gpaNumberField);
		this.add(letterField);
		this.add(keyValueField);
		this.add(courseCodeField);
		this.add(createClass);
		this.add(createGrade);
		
	}
	
	private boolean checkInteger(String currentInput){
		boolean isInteger = false;
		try{
			Integer.parseInt(currentInput);
			isInteger = true;
		}catch(NumberFormatException currentException){
			JOptionPane.showMessageDialog(this, "Please enter a single number");
		}
		return isInteger;
	}
	
	private boolean checkDouble(String currentInput){
		boolean isDouble = false;
		try{
			Double.parseDouble(currentInput);
			isDouble = true;
		}catch(NumberFormatException currentException){
			JOptionPane.showMessageDialog(this, "Please enter a double number");
		}
		return isDouble;
	}
	//These listeners will take the data from above and pass them to the controller for use.
	private void setUpListeners() {
		createClass.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent click) {
				String courseCode = courseCodeLabel.getText();
				int keyValue = 0;
				if(checkInteger(keyValueField.getText())){
					keyValue = Integer.parseInt(keyValueField.getText());
					
					/*This was used to verify that my code was reaching where it needed too.
					//calls the classT for us to temporarily store the data to pass on.
					ClassT tempClass = new ClassT(keyValue,courseCode);
					//connects to the controler and then conects to the model... you get it right?
					baseController.getStudentClasses().getClassList().add(tempClass);
					*/
					//This code actually stores the data in the model.
					if(baseController.getStudentClasses().makeClass(keyValue, courseCode)){
						JOptionPane.showMessageDialog(baseController.getAppFrame(), "Your Class Was Added to the List");
					}else{
						JOptionPane.showMessageDialog(baseController.getAppFrame(), "Sorry! Your Class Was NOT Added to the List");
					}
				}
			}
		});
		
		createGrade.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent click) {
				String letter = letterField.getText();
				double gpaNumber = 0.0;
				if(checkDouble(gpaNumberField.getText())){
					gpaNumber = Double.parseDouble(keyValueField.getText());
					/*this was used to test if my code was making it to the model.
					//calls the grade for us to temporarily store the data to pass on.
					Grade tempGrade = new Grade(gpaNumber,letter);
					//connects to the controler and then conects to the model... you get it right?
					baseController.getStudentClasses().getGradeList().add(tempGrade);
					*/
					//This code actually stores the data in the model.
					if(baseController.getStudentClasses().makeGrade(gpaNumber,letter)){
						JOptionPane.showMessageDialog(baseController.getAppFrame(), "Your Grade Was Added to the List");
					}else{
						JOptionPane.showMessageDialog(baseController.getAppFrame(), "Sorry! Your Grade Was NOT Added to the List");
					}
				}
			}
		});
	
	
	}
}
