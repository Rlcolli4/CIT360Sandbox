package samplemodel;

public class ClassT {
	//Create the values for use.
	private Integer keyValue;
	private String courseCode;
	
	public ClassT(Integer keyValue, String courseCode) {
		this.keyValue = keyValue;
		this.courseCode = courseCode;
	}

	public Integer getKeyValue() {
		return keyValue;
	}

	public void setKeyValue(Integer keyValue) {
		this.keyValue = keyValue;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}
}
