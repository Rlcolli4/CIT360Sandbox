package samplemodel;

import java.util.*;

public class Student {
	//Create private accessors to get to our Classes and Grades
	//For our sakes we will use a list class to access them.
	private ArrayList<ClassT> classList;
	private ArrayList<Grade> gradeList;
	private int classResource;
	private int gradeResource; 
	
	//now we wil construct everything.
	public Student() {
		classList = new ArrayList<ClassT>();
		gradeList = new ArrayList<Grade>();
		
		//Notice the limits on the resources. We can have several classes but for the sake of the grades only 5 (A-B-C-D-F)
		classResource = 50;
		gradeResource = 5; 
	}
	
	public ArrayList<ClassT> getClassList() {
		return classList;
	}

	public void setClassList(ArrayList<ClassT> classList) {
		this.classList = classList;
	}

	public ArrayList<Grade> getGradeList() {
		return gradeList;
	}

	public void setGradeList(ArrayList<Grade> gradeList) {
		this.gradeList = gradeList;
	}

	public int getClassResource() {
		return classResource;
	}

	public void setClassResource(int classResource) {
		this.classResource = classResource;
	}

	public int getGradeResource() {
		return gradeResource;
	}

	public void setGradeResource(int gradeResource) {
		this.gradeResource = gradeResource;
	}

	//These are here to make sure we don't use more of the resources provided above, so it will return true or false to use.
	//These make methods will use the same information we need to have these items in the Class.Java and the Grade.Java classes.
	public boolean makeClass(Integer keyValue, String courseCode){
		//This will get changed later if the classResource is good to go.
		Boolean canMakeC = false;
		
		if (classResource > 0) {
			ClassT currentClass = new ClassT(keyValue, courseCode);
			classResource--;
			classList.add(currentClass);
			canMakeC = true;
		}
		
		return canMakeC;
	}
	
	public boolean makeGrade(double gpaNumber, String letter){
		Boolean canMakeG = false;
		
		if (gradeResource > 0) {
			Grade currentGrade = new Grade(gpaNumber, letter);
			gradeResource--;
			gradeList.add(currentGrade);
			canMakeG = true;
		}
		
		return canMakeG;
	}
}
