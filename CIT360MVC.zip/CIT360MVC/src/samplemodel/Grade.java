package samplemodel;

public class Grade {
	private double gpaNumber;
	private String letter;
	
	public Grade(double gpaNumber, String letter){
		this.gpaNumber = gpaNumber;
		this.letter = letter;
	}

	public double getGpaNumber() {
		return gpaNumber;
	}

	public void setGpaNumber(double gpaNumber) {
		this.gpaNumber = gpaNumber;
	}

	public String getLetter() {
		return letter;
	}

	public void setLetter(String letter) {
		this.letter = letter;
	}
	
}
