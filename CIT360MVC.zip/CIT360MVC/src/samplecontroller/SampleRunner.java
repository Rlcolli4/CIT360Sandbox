package samplecontroller;
/*
 * This contains our main method that we will use when we start up the application.
 */
public class SampleRunner {
	/*
	 * This main starter method is used pretty generically, you may notice we have the 
	 * String[] args, but we do not use it as this is coded for a gui application.
	 */
	public static void main(String[] args) {
		// Now we ware going to make a new SampleController using our Controller above so that we can send information to it.
		SampleController getStudent = new SampleController();
		getStudent.start(); //This is "boiler" code, or it loads our code so it is prepared to go when we are ready for it.

	}

}
