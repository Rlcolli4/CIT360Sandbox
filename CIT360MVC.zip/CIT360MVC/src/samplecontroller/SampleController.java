package samplecontroller;

import samplemodel.Student;
import samplemodel.Grade;
import samplemodel.ClassT;
import sampleview.SampleFrame; //Used to reference teh frame.

/*
 * This defines the controller that our application will use when it runs for our users.
 * From here it will take the data input from teh user and determine what to do with it in the other classes
 * and packages.
 */
public class SampleController {

	//This reference allows us to bring up a window with the code we ahve made in the SampleView.
	private SampleFrame appFrame;
	
	//The following code gives us reference to the model so we can access and use it.
	private Student studentClasses;

	//Gets the Student from there
	public Student getStudentClasses() {
		return studentClasses;
	}
	//No setter because we are not changing anything.
	
	public SampleFrame getAppFrame(){
		return appFrame;
	}
	
	//This method calls the constructors for our get methods above.
	public SampleController() {
		studentClasses = new Student();
	}
	
	public void start() { //This connects to the SampleRunner and will go on app start up.
		// The start method will call the reference made above and the constructor in teh approrpiate class will build it for us.
		appFrame = new SampleFrame(this); //This passes a refrence of what we are in now.
		
	}

}
